import React, { Component } from 'react'
import { Collapse, CardBody, Card } from 'reactstrap';
import { Link } from 'react-router-dom'
import './style.css';

const menus = [
    {
        id: 1,
        title: 'منزل، بيت',
        link: '/home',
        submenu: [
            {
                id: 11,
                title: 'نمط المنزل 1',
                link: '/home'
            },
            {
                id: 12,
                title: 'نمط المنزل 2',
                link: '/home2'
            },
        ]
    },

    {
        id: 2,
        title: 'حول',
        link: '/about',
    },

{
    id: 3,
        title: 'الأسباب',
        link: '/case',
        submenu: [
            {
                id: 31,
                title: 'الأسباب',
                link: '/case'
            },
            {
                id: 32,
                title: 'أسباب فردية',
                link: '/case-single'
            }
        ]
    },
{
    id: 4,
        title: 'حدث',
        link: '/event',
        submenu: [
            {
                id: 41,
                title: 'حدث',
                link: '/event'
            },
            {
                id: 42,
                title: 'حدث واحد',
                link: '/event-details'
            }
        ]
    },
    {
        id: 7,
        title: 'الصفحات',
        link: '/',
        submenu: [
            {
                id: 71,
                title: 'حول',
                link: '/about'
            },
            {
                id: 75,
                title: 'يتبرع',
                link: '/donate'
            },
            {
                id: 76,
                title: 'متطوع',
                link: '/volunteer'
            },
    
            {
                id: 79,
                title: 'خطأ 404',
                link: '/404'
            },
            
        ]
    },

    {
        id: 5,
        title: 'مدونة او مذكرة',
        link: '/blog',
        submenu: [
            {
                id: 51,
                title: 'مدونة او مذكرة',
                link: '/blog'
            },
            {
                id: 52,
                title: 'بلوق الشريط الجانبي الأيسر',
                link: '/blog-left'
            },
            {
                id: 53,
                title: 'مدونة كاملة العرض',
                link: '/blog-fullwidth'
            },
            {
                id: 54,
                title: 'مدونة واحدة',
                link: '/blog-details'
            },
            {
                id: 55,
                title: 'مدونة الشريط الجانبي الأيسر الفردي',
                link: '/blog-details-left'
            },
            {
                id: 56,
                title: 'مدونة الشريط الجانبي الأيسر الفردي',
                link: '/blog-details-fullwidth'
            },
        ]
    },
    {
        id: 88,
        title: 'اتصال',
        link: '/contact',
    }
    
    
]


export default class MobileMenu extends Component {

    state = {
        isMenuShow: false,
        isOpen: 0,
    }

    menuHandler = () => {
        this.setState({
            isMenuShow: !this.state.isMenuShow
        })
    }

    setIsOpen = id => () => {
        this.setState({
            isOpen: id === this.state.isOpen ? 0 : id
        })
    }

    render() {

        const { isMenuShow, isOpen } = this.state;

        return (
            <div>
                <div className={`mobileMenu ${isMenuShow ? 'show' : ''}`}>
                    <div className="clox" onClick={this.menuHandler}><i className="fa fa-close"></i></div>

                    <ul className="responsivemenu">
                        {menus.map(item => {
                            return (
                                <li key={item.id}>
                                    {item.submenu ? <p onClick={this.setIsOpen(item.id)}>
                                        {item.title}
                                        {item.submenu ? <i className="fa fa-angle-right" aria-hidden="true"></i> : ''}
                                    </p> : <Link to={item.link}>{item.title}</Link>}
                                    {item.submenu ?
                                    <Collapse isOpen={item.id === isOpen}>
                                        <Card>
                                            <CardBody>
                                                <ul>
                                                    {item.submenu.map(submenu => (
                                                        <li key={submenu.id}><Link className="active" to={submenu.link}>{submenu.title}</Link></li>
                                                    ))}
                                                </ul>
                                            </CardBody>
                                        </Card>
                                    </Collapse>
                                    : ''}
                                </li>
                            )
                        })}
                    </ul>

                </div>

                <div className="showmenu" onClick={this.menuHandler}><i className="fa fa-bars" aria-hidden="true"></i></div>
            </div>
        )
    }
}
